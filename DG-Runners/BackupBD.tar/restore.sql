--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.9
-- Dumped by pg_dump version 9.6.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY sitecorridas.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY sitecorridas.corridas DROP CONSTRAINT corridas_pkey;
ALTER TABLE sitecorridas.usuarios ALTER COLUMN pk_coduser DROP DEFAULT;
ALTER TABLE sitecorridas.corridas ALTER COLUMN pk_codcorridas DROP DEFAULT;
DROP SEQUENCE sitecorridas.usuarios_pk_coduser_seq;
DROP TABLE sitecorridas.usuarios;
DROP SEQUENCE sitecorridas.corridas_pk_codcorridas_seq;
DROP TABLE sitecorridas.corridas;
DROP EXTENSION plpgsql;
DROP SCHEMA sitecorridas;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: sitecorridas; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sitecorridas;


ALTER SCHEMA sitecorridas OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: corridas; Type: TABLE; Schema: sitecorridas; Owner: postgres
--

CREATE TABLE sitecorridas.corridas (
    pk_codcorridas integer NOT NULL,
    nome character varying(50),
    descricao character varying(50),
    valor character varying(50),
    img character varying(400),
    imgbannerindex character varying(200)
);


ALTER TABLE sitecorridas.corridas OWNER TO postgres;

--
-- Name: corridas_pk_codcorridas_seq; Type: SEQUENCE; Schema: sitecorridas; Owner: postgres
--

CREATE SEQUENCE sitecorridas.corridas_pk_codcorridas_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sitecorridas.corridas_pk_codcorridas_seq OWNER TO postgres;

--
-- Name: corridas_pk_codcorridas_seq; Type: SEQUENCE OWNED BY; Schema: sitecorridas; Owner: postgres
--

ALTER SEQUENCE sitecorridas.corridas_pk_codcorridas_seq OWNED BY sitecorridas.corridas.pk_codcorridas;


--
-- Name: usuarios; Type: TABLE; Schema: sitecorridas; Owner: postgres
--

CREATE TABLE sitecorridas.usuarios (
    pk_coduser integer NOT NULL,
    nome character varying(50),
    email character varying(50),
    senha character varying(50),
    telefone character varying(50),
    cep character varying(50),
    endereco character varying(100),
    complemento character varying(50),
    bairro character varying(50),
    cidade character varying(50),
    estado character varying(50),
    pais character varying(50),
    numend character varying(50),
    sexo character varying(50),
    datanasc character varying(50)[]
);


ALTER TABLE sitecorridas.usuarios OWNER TO postgres;

--
-- Name: usuarios_pk_coduser_seq; Type: SEQUENCE; Schema: sitecorridas; Owner: postgres
--

CREATE SEQUENCE sitecorridas.usuarios_pk_coduser_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sitecorridas.usuarios_pk_coduser_seq OWNER TO postgres;

--
-- Name: usuarios_pk_coduser_seq; Type: SEQUENCE OWNED BY; Schema: sitecorridas; Owner: postgres
--

ALTER SEQUENCE sitecorridas.usuarios_pk_coduser_seq OWNED BY sitecorridas.usuarios.pk_coduser;


--
-- Name: corridas pk_codcorridas; Type: DEFAULT; Schema: sitecorridas; Owner: postgres
--

ALTER TABLE ONLY sitecorridas.corridas ALTER COLUMN pk_codcorridas SET DEFAULT nextval('sitecorridas.corridas_pk_codcorridas_seq'::regclass);


--
-- Name: usuarios pk_coduser; Type: DEFAULT; Schema: sitecorridas; Owner: postgres
--

ALTER TABLE ONLY sitecorridas.usuarios ALTER COLUMN pk_coduser SET DEFAULT nextval('sitecorridas.usuarios_pk_coduser_seq'::regclass);


--
-- Data for Name: corridas; Type: TABLE DATA; Schema: sitecorridas; Owner: postgres
--

COPY sitecorridas.corridas (pk_codcorridas, nome, descricao, valor, img, imgbannerindex) FROM stdin;
\.
COPY sitecorridas.corridas (pk_codcorridas, nome, descricao, valor, img, imgbannerindex) FROM '$$PATH$$/2173.dat';

--
-- Name: corridas_pk_codcorridas_seq; Type: SEQUENCE SET; Schema: sitecorridas; Owner: postgres
--

SELECT pg_catalog.setval('sitecorridas.corridas_pk_codcorridas_seq', 9, true);


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: sitecorridas; Owner: postgres
--

COPY sitecorridas.usuarios (pk_coduser, nome, email, senha, telefone, cep, endereco, complemento, bairro, cidade, estado, pais, numend, sexo, datanasc) FROM stdin;
\.
COPY sitecorridas.usuarios (pk_coduser, nome, email, senha, telefone, cep, endereco, complemento, bairro, cidade, estado, pais, numend, sexo, datanasc) FROM '$$PATH$$/2175.dat';

--
-- Name: usuarios_pk_coduser_seq; Type: SEQUENCE SET; Schema: sitecorridas; Owner: postgres
--

SELECT pg_catalog.setval('sitecorridas.usuarios_pk_coduser_seq', 109, true);


--
-- Name: corridas corridas_pkey; Type: CONSTRAINT; Schema: sitecorridas; Owner: postgres
--

ALTER TABLE ONLY sitecorridas.corridas
    ADD CONSTRAINT corridas_pkey PRIMARY KEY (pk_codcorridas);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: sitecorridas; Owner: postgres
--

ALTER TABLE ONLY sitecorridas.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (pk_coduser);


--
-- PostgreSQL database dump complete
--

